package com.Tables.Multiplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;


public class HomeActivity2 extends AppCompatActivity {

    private Button ShareButton;

    private Button OneToTenbtn;
    private Button ElevenToTwentybtn;
    private Button TwentyoneToThirtybtn;
    private Button ThirtyoneTofourtybtn;
    private Button FourtyoneToFiftybtn;
    private Button FiftyoneToSixtyybtn;
    private Button SixtyOneToSeventybtn;
    private Button SeventyOneToEightybtn;
    private Button EightyOneToNintybtn;
    private Button NintyOneToHundredbtn;

    private AdView mAdView;



    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Do You Want to Exit?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        HomeActivity2.super.onBackPressed();


                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        dialogInterface.cancel();

                    }
                });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home2);



        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);


        ShareButton = (Button) findViewById(R.id.ShareButton);
        ShareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                String shareBody = "https://play.google.com/store/apps/details?id=com.Table.Multiplication";//
                String shareSub = "Multiplication Tables";

                shareIntent.putExtra(Intent.EXTRA_SUBJECT,shareSub);
                shareIntent.putExtra(Intent.EXTRA_TEXT,shareBody);

                startActivity(Intent.createChooser(shareIntent,"Share Using"));

            }
        });



        OneToTenbtn = findViewById(R.id.OneToTenbtn);

        OneToTenbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent categoryIntent = new Intent(HomeActivity2.this,OneToTen.class);
                startActivity(categoryIntent);
                finish();
            }
        });

        ElevenToTwentybtn = findViewById(R.id.ElevenToTwentybtn);

        ElevenToTwentybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent categoryIntent = new Intent(HomeActivity2.this,Eleven11.class);
                startActivity(categoryIntent);
                finish();


            }
        });

        TwentyoneToThirtybtn = findViewById(R.id.TwentyoneToThirtybtn);

        TwentyoneToThirtybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent categoryIntent = new Intent(HomeActivity2.this,TwentyOne21.class);
                startActivity(categoryIntent);
                finish();


            }
        });

        ThirtyoneTofourtybtn = findViewById(R.id.ThirtyoneTofourtybtn);

        ThirtyoneTofourtybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent categoryIntent = new Intent(HomeActivity2.this,ThirtyOne31.class);
                startActivity(categoryIntent);
                finish();


            }
        });
        FourtyoneToFiftybtn = findViewById(R.id.FourtyoneToFiftybtn);

        FourtyoneToFiftybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent categoryIntent = new Intent(HomeActivity2.this,FortyOne41.class);
                startActivity(categoryIntent);
                finish();


            }
        });



        FiftyoneToSixtyybtn = findViewById(R.id.FiftyoneToSixtyybtn);

        FiftyoneToSixtyybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent categoryIntent = new Intent(HomeActivity2.this,FiftyOne51.class);
                startActivity(categoryIntent);
                finish();


            }
        });

        SixtyOneToSeventybtn = findViewById(R.id.SixtyOneToSeventybtn);

        SixtyOneToSeventybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent categoryIntent = new Intent(HomeActivity2.this,SixtyOne61.class);
                startActivity(categoryIntent);
                finish();


            }
        });

        SeventyOneToEightybtn = findViewById(R.id.SeventyOneToEightybtn);

        SeventyOneToEightybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent categoryIntent = new Intent(HomeActivity2.this,SeventyOne71.class);
                startActivity(categoryIntent);
                finish();


            }
        });

        EightyOneToNintybtn = findViewById(R.id.EightyOneToNintybtn);

        EightyOneToNintybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent categoryIntent = new Intent(HomeActivity2.this,EightyOne81.class);
                startActivity(categoryIntent);
                finish();


            }
        });

        NintyOneToHundredbtn = findViewById(R.id.NintyOneToHundredbtn);

        NintyOneToHundredbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent categoryIntent = new Intent(HomeActivity2.this,NintyOne91.class);
                startActivity(categoryIntent);
                finish();


            }
        });






    }
}