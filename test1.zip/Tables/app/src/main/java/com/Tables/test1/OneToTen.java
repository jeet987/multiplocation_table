package com.Tables.Multiplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class OneToTen extends AppCompatActivity {

    private Button Next;
    private Button Home;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_one_to_ten);

        Next = findViewById(R.id.Next);
        Home = findViewById(R.id.Home);
        
        Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent categoryIntent = new Intent(OneToTen.this,Two.class);
                startActivity(categoryIntent);
                finish();
            }
        });

        Home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent categoryIntent = new Intent(OneToTen.this,HomeActivity2.class);
                startActivity(categoryIntent);
                finish();
            }
        });

        getSupportActionBar().setHomeButtonEnabled(true);//
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);//

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();
        if (id == android.R.id.home) {
            Intent categogyIntent = new Intent(OneToTen.this, HomeActivity2.class);
            startActivity(categogyIntent);
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        Intent categogyIntent = new Intent(OneToTen.this, HomeActivity2.class);
        startActivity(categogyIntent);
        finish();
    }
}



