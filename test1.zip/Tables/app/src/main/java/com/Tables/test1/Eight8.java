package com.Tables.Multiplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class Eight8 extends AppCompatActivity {
    private Button Next;
    private Button Home;
    private Button Prev;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eight8);

        Next = findViewById(R.id.Next);
        Home = findViewById(R.id.Home);
        Prev = findViewById(R.id.Prev);
        Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent categoryIntent = new Intent(Eight8.this, Nine9.class);
                startActivity(categoryIntent);
                finish();
            }
        });
        Home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent categoryIntent = new Intent(Eight8.this,HomeActivity2.class);
                startActivity(categoryIntent);
                finish();
            }
        });
        Prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent categoryIntent = new Intent(Eight8.this,Seven7.class);
                startActivity(categoryIntent);
                finish();
            }
        });
        getSupportActionBar().setHomeButtonEnabled(true);//
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);//
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();
        if (id == android.R.id.home) {
            Intent categogyIntent = new Intent(Eight8.this, HomeActivity2.class);
            startActivity(categogyIntent);
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        Intent categogyIntent = new Intent(Eight8.this, HomeActivity2.class);
        startActivity(categogyIntent);
        finish();
    }
}